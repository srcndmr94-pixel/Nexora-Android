# NEXORA Android — telefon altyazı çeviricisi

Bu proje Android ekranını MediaProjection ile yakalar, ekranın alt bölümündeki oyun altyazılarını ML Kit OCR ile okur, İngilizceden Türkçeye cihaz üzerinde çevirir ve sonucu kayan altyazı penceresinde gösterir. Ses dinlemez.

## Bu sürümde yapılan düzeltmeler
- ML Kit İngilizce→Türkçe modeli indirilmeden çeviri başlatılmaz; model hazır değilse kullanıcıya durum gösterilir.
- OCR kareleri üst üste bindirilmez; kare, OCR işlemi tamamlandığında serbest bırakılır.
- OCR metni normalize edilir, tekrar eden satırlar filtrelenir ve çeviriler sıraya alınır.
- Ekranın alt %42'si taranır; menü/tuş yönergeleri (ör. “X Exit See Shop”, “O Dive”, “Swim Up Lunge”) elenir.
- Kayan altyazı ekranın altına taşındı ve uygulama adı NEXORA olarak güncellendi.

## Kurulum ve kullanım
1. Android Studio'da bu klasörü aç (JDK 17, Android SDK 35).
2. Gradle senkronizasyonunu tamamla ve `app` için Debug APK oluştur.
3. Telefonda NEXORA'yı aç; “Altyazı penceresi iznini ver” seçeneğini etkinleştir.
4. “Ekran yakalamayı başlat” düğmesine bas ve Android ekran yakalama iznini onayla.
5. PS Remote Play'e dön ve oyunda İngilizce altyazıları aç.
6. İlk kullanımda ML Kit Türkçe çeviri modeli indirilirken internet bağlantısı açık olmalı.

## Önemli sınır
PS Remote Play görüntüsü Android tarafından korumalı/siyah kare olarak sunulursa MediaProjection OCR yapamaz. Bu korumayı uygulama içinden aşmak mümkün değildir. Önce cihazda gerçek görüntü yakalanabildiği doğrulanmalıdır.

## Lisans
Orijinal CouchSubs projesi AGPL-3.0 lisanslıdır: https://github.com/yorulmazsinan/couchsubs
